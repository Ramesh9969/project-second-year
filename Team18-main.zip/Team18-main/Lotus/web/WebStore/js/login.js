//function login() {
//
//    var e = document.getElementById("email");
//    var p = document.getElementById("pass");
//
//    if (e.value === "") {
//        var popup = document.getElementById("emailPopup");
//        popup.classList.add("show");
//    } else if (p.value === "") {
//        var popup = document.getElementById("passPopup");
//        popup.classList.add("show");
//    } else {
//
//        var request = new XMLHttpRequest();
//
//        request.onreadystatechange = function () {
//
//            if (request.readyState === 4) {
//                if (request.status === 200) {
//                    var response = request.responseText;
//                    if (response === "1") {
//                        window.location = "index.jsp";
//                    } else {
//                        openModel(response);
//                    }
//                }
//            }
//        }
//
//        request.open("POST", "Login", true);
//        request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
//        request.send("email=" + e.value + "&pass=" + p.value);
//    }
//}

function clearTextEmail() {

    var e = document.getElementById("email");
    var popup = document.getElementById("emailPopup");

    e.placeholder = "";
    popup.classList.remove("show");
}

function clearTextPassword() {

    var p = document.getElementById("pass");
    var popup = document.getElementById("passPopup");

    p.placeholder = "";
    popup.classList.remove("show");
}

function setTextEmail() {

    var e = document.getElementById("email");

    e.placeholder = "enter your email";

}

function setTextPassword() {

    var p = document.getElementById("pass");

    p.placeholder = "enter the password";

}

function setTextRePassword() {

    var p = document.getElementById("repass");

    p.placeholder = "re-enter the password";

}

function clearTextRePassword() {

    var p = document.getElementById("repass");
    var popup = document.getElementById("repassPopup");

    p.placeholder = "";
    popup.classList.remove("show");
}

function clearTextName() {

    var e = document.getElementById("name");
    var popup = document.getElementById("namePopup");

    e.placeholder = "";
    popup.classList.remove("show");
}

function setTextName() {

    var e = document.getElementById("name");

    e.placeholder = "enter your name";

}



function signUp() {

    var n = document.getElementById("name");
    var e = document.getElementById("email");
    var p = document.getElementById("pass");
    var r = document.getElementById("repass");

    if (n.value === "") {
        var popup = document.getElementById("namePopup");
        popup.classList.add("show");
    } else if (e.value === "") {
        var popup = document.getElementById("emailPopup");
        popup.classList.add("show");
    } else if (p.value === "") {
        var popup = document.getElementById("passPopup");
        popup.classList.add("show");
    } else if (r.value === "") {
        var popup = document.getElementById("repassPopup");
        popup.classList.add("show");
    } else {


        if (p.value !== r.value) {

            openModel("Passwords do not match");
        } else {

            var request = new XMLHttpRequest();

            request.onreadystatechange = function () {

                if (request.readyState === 4) {
                    if (request.status === 200) {
                        var response = request.responseText;
                        if (response === "1") {
                            window.location = "profile.jsp";
                        } else {
                            openModel(response);
                        }
                    }
                }
            }
        }



        request.open("POST", "signUp", true);
        request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        request.send("fname=" + n.value + "&email=" + e.value + "&pass=" + p.value + "&repass=" + r.value);
    }
}