function removeShippingRegion(shippingRegionId) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;
                document.getElementById("sr-table-div").innerHTML = response;
            }
        }
    };

    request.open("GET", "RemoveShippingRegion?srId=" + shippingRegionId, true);
    request.send();
}

function addNewShippingRegion() {

    var shippingRegion = document.getElementById("sr").value;

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;

                document.getElementById("sr-table-div").innerHTML = response;
               document.getElementById("sr").value=null;
            }
        }
    };

    request.open("GET", "AddShippingRegion?shippingRegion=" + shippingRegion, true);
    request.send();
}
