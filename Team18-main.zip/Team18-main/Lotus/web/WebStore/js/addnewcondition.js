function removeCondition(conId) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;
                document.getElementById("con-table-div").innerHTML = response;
            }
        }
    };

    request.open("GET", "RemoveCondition?conId=" + conId, true);
    request.send();
}

function addNewCondition() {

    var condition = document.getElementById("con").value;

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;

                document.getElementById("con-table-div").innerHTML = response;
               document.getElementById("con").value=null;
            }
        }
    };

    request.open("GET", "AddCondition?condition=" + condition, true);
    request.send();
}
