function generateInvoice() {
    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                var w = window.open("data:text/html,<b>hi</b> <i>italics</i>", "_blank");

                w.document.write(response);


                w.print();
                w.close();
            }
        }
    };

    request.open("GET", "GenerateInvoice", true);
    request.send();
}