var buyItNow_State = false;

function loadCart() {

    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;
                var count = response.split(",")[0];
                var content = response.split(",")[1];
                var checkout = response.split(",")[2];
                document.getElementById("product-count").innerHTML = count;
                document.getElementById("main").innerHTML = content;
                document.getElementById("checkout-div").innerHTML = checkout;
          
            }
        }
    };
    request.open("GET", "../LoadCart", true);
    request.send();
}

function searchCart() {

    var search = document.getElementById("search-cart").value;
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;
                var count = response.split(",")[0];
                var content = response.split(",")[1];
                var checkout = response.split(",")[2];
                document.getElementById("product-count").innerHTML = count;
                document.getElementById("main").innerHTML = content;
                document.getElementById("checkout-div").innerHTML = checkout;
            }
        }
    };
    request.open("GET", "../SearchCart?search=" + search, true);
    request.send();
}

function removeCartItem(id) {

    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;
                if (response === "1") {
                    location.reload();
                    loadCart();

                } else {
                    openModel(response);
                }
            }
        }
    };
    request.open("GET", "../RemoveCartItem?cid=" + id, false);
    request.send();
}

function updateCart(cartId) {

    var qty = document.getElementById("qty" + cartId).value;
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;
                alert(response);
                window.location.reload();
            }
        }
    };
    request.open("GET", "../UpdateCart?cid=" + cartId + "&qty=" + qty, true);
    request.send();
}

function checkout() {
    buyItNow_State = false;
    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;
                payment = JSON.parse(response);
                payhere.startPayment(payment);
            }
        }
    };

    request.open("GET", "Checkout", false);
    request.send();

}

function generateInvoice() {
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;
                if (response === "0") {
                    openModel("You have to log in, first");
                } else if (response === "1") {
                    openModel("You have no items in your cart");

                } else {


                    var w = window.open("", "Report");

                    w.document.write(response);

                    w.print();
                    w.close();

                    loadCart();
                    location.reload();
                }


            }
        }
    };
    request.open("GET", "GenerateInvoice", true);
    request.send();
}

function buyItNow(cid) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;

                if (response === "0") {
                    // nothing to do
                } else if (response.includes("ERROR::")) {

                    var res = response.split("ERROR::")[1];
                    openModel(res);
                } else {

                    buyItNow_State = true;
                    payment = JSON.parse(response);
                    payhere.startPayment(payment);
                }
            }
        }
    };

    request.open("GET", "BuyItNowCart?cid=" + cid, true);
    request.send();
}

function activateBuyItNowCart() {

    buyItNow_State = false;
    var request = new XMLHttpRequest();

    request.open("GET", "ActivateBuyItNowCart", true);
    request.send();

}

function generateBuyItNowInvoice() {

    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;
                if (response === "0") {
                    openModel("You have to log in, first");
                } else if (response === "1") {
                    openModel("You have no items in your cart");

                } else {

                    var w = window.open("", "Report");
                    w.document.write(response);

                    w.print();
                    w.close();

                    loadCart();
                    location.reload();
                }


            }
        }
    };

    buyItNow_State = false;

    request.open("GET", "GenerateBuyItNowInvoice", true);
    request.send();
}

function resetCart() {

    var request = new XMLHttpRequest();

    request.open("GET", "ResetCart", true);
    request.send();

}