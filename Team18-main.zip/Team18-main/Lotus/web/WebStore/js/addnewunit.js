function removeUnit(unitId) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;
                document.getElementById("uni-table-div").innerHTML = response;
            }
        }
    };

    request.open("GET", "RemoveUnit?unitId=" + unitId, true);
    request.send();
}

function addNewUnit() {

    var uni = document.getElementById("uni").value;

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;

                document.getElementById("uni-table-div").innerHTML = response;
                document.getElementById("uni").value = null;
            }
        }
    };

    request.open("GET", "AddUnit?uni=" + uni, true);
    request.send();
}
