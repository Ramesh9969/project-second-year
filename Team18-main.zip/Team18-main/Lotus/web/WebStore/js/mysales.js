function loadSales() {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                var count = response.split(",")[0];
                var content = response.split(",")[1];
                var checkout = response.split(",")[2];


                document.getElementById("product-count").innerHTML = count;
                document.getElementById("main").innerHTML = content;
                document.getElementById("checkout-div").innerHTML = checkout;
            }
        }
    };

    request.open("GET", "../LoadSales", true);
    request.send();

}

function searchSales() {

    var search = document.getElementById("search-sales").value;

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                var count = response.split(",")[0];
                var content = response.split(",")[1];
                var checkout = response.split(",")[2];


                document.getElementById("product-count").innerHTML = count;
                document.getElementById("main").innerHTML = content;
                document.getElementById("checkout-div").innerHTML = checkout;
            }
        }
    };

    request.open("GET", "../SearchSales?search=" + search, true);
    request.send();

}

function changeStatus(id) {

    var status = document.getElementById(id + "status").value;
    var request = new XMLHttpRequest();
    request.open("GET", "UpdateStatus?status=" + status + "&id=" + id, true);
    request.send();
}