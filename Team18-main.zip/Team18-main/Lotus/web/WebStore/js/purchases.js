function loadPurchases() {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                var count = response.split(",")[0];
                var content = response.split(",")[1];
                var checkout = response.split(",")[2];


                document.getElementById("product-count").innerHTML = count;
                document.getElementById("main").innerHTML = content;
                document.getElementById("checkout-div").innerHTML = checkout;
            }
        }
    };

    request.open("GET", "../LoadPurchases", true);
    request.send();

}

function searchPurchases() {

    var search = document.getElementById("search-purchase").value;

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                var count = response.split(",")[0];
                var content = response.split(",")[1];
                var checkout = response.split(",")[2];


                document.getElementById("product-count").innerHTML = count;
                document.getElementById("main").innerHTML = content;
                document.getElementById("checkout-div").innerHTML = checkout;
            }
        }
    };

    request.open("GET", "../SearchPurchases?search=" + search, true);
    request.send();

}

function markAsReceived(id) {
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                loadPurchases();
                location.reload();
            }
        }
    };
    request.open("GET", "../MarkAsReceived?id=" + id, true);
    request.send();

}