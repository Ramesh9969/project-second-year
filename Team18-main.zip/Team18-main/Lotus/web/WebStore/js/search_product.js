function loadProducts() {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {

        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;

                var count = response.split(",,,")[0];
                var content = response.split(",,,")[1];

                document.getElementById("product-count").innerHTML = count;
                document.getElementById("productContainer").innerHTML = content;
            }
        }

    };

    request.open("GET", "../LoadProduct", true);
    request.send();

}


function addToCart(productId) {

    var qty = document.getElementById("qty" + productId).value;
    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;

                var inputs = document.getElementsByClassName("product-card-qty-input");
                for (var item in inputs) {
                    inputs[item].value = "";
                }

                if (response.includes("ERROR::")) {
                    var msg = response.split("ERROR::")[1];
                    openModel(msg);
                } else {
                    openInfoModel(response);

                }
            }
        }
    };
    request.open("GET", "../AddToCart?pid=" + productId + "&qty=" + qty, true);
    request.send();

}

function viewProducts(id) {

    window.location = "viewproduct.jsp?id=" + id;

}

function addToWishList(id) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;
                if (response === "1") {
                    document.getElementById("img" + id).src = "img/icons8_Heart_Outline_24px.png";

                } else if (response === "0") {
                    document.getElementById("img" + id).src = "img/icons8_Heart_24px_1.png";

                } else {
                    openModel(response);
                }
            }
        }
    };

    request.open("GET", "../AddToWishList?sid=" + id, true);
    request.send();
}


function searchProduct(name) {
    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;

                var count = response.split(",,,")[0];
                var content = response.split(",,,")[1];


                document.getElementById("product-count").innerHTML = count;
                document.getElementById("productContainer").innerHTML = content;
            }
        }
    };

    request.open("GET", "SearchProductName?name=" + name, true);
    request.send();
}

function searchNavbarProduct(name) {
    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;

                var count = response.split(",,,")[0];
                var content = response.split(",,,")[1];


                document.getElementById("product-count").innerHTML = count;
                document.getElementById("productContainer").innerHTML = content;
            }
        }
    };

    request.open("GET", "../SearchNavbarProductName?name=" + name, true);
    request.send();
}

function clearSearch() {
    window.location = "search_product.jsp";
}


function buyItNow(sellingId) {

    var qty = document.getElementById("qty" + sellingId).value;

    if (qty === "") {
        // nothing to do
    } else {
        var request = new XMLHttpRequest();

        request.onreadystatechange = function () {
            if (request.readyState === 4) {
                if (request.status === 200) {
                    var response = request.responseText;

                    var inputs = document.getElementsByClassName("product-card-qty-input");
                    for (var item in inputs) {
                        inputs[item].value = "";
                    }

                    if (response === "0") {
                        // nothing to do
                    } else if (response.includes("ERROR::")) {

                        var res = response.split("ERROR::")[1];
                        openModel(res);
                    } else {

                        payment = JSON.parse(response);
                        payhere.startPayment(payment);
                    }
                }
            }
        };
        request.open("GET", "BuyItNow?sid=" + sellingId + "&qty=" + qty, false);
        request.send();
    }


}

function removeBuyItNowCart() {

    var request = new XMLHttpRequest();

    request.open("GET", "RemoveBuyItNow", true);
    request.send();

}

function generateBuyItNowInvoice() {

    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;
                if (response === "0") {
                    openModel("You have to log in, first");
                } else if (response === "1") {
                    openModel("You have no items in your cart");

                } else {

                    var w = window.open("#", "Report");
                    w.document.write(response);
                    location.reload();
                    w.print();
                    w.close();

                }


            }
        }
    };
    request.open("GET", "GenerateBuyItNowInvoice", true);
    request.send();
}