document.getElementById("logo").onclick = function () {

    window.location = "index.jsp";
};

function login() {
    window.location = "login.jsp";
}