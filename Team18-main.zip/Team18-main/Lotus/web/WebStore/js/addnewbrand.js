function removeBrand(brandId) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;
                document.getElementById("br-table-div").innerHTML = response;
            }
        }
    };

    request.open("GET", "RemoveBrand?brandId=" + brandId, true);
    request.send();
}

function addNewBrand() {

    var brand = document.getElementById("br").value;

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;

                document.getElementById("br-table-div").innerHTML = response;
                document.getElementById("br").value = null;
            }
        }
    };

    request.open("GET", "AddBrand?brand=" + brand, true);
    request.send();
}
