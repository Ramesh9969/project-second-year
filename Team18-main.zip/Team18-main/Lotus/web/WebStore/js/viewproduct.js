function changeImage(img) {
    document.getElementById("myimage").src = img.src;
    //document.getElementsByClassName("img-zoom-lens").style.display="none";
    imageZoom("myimage", "myresult");
}

function addToCart(productId, qty) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;
                if (response.includes("ERROR::")) {
                    var msg = response.split("ERROR::")[1];
                    openModel(msg);
                } else {
                    openInfoModel(response);

                }
            }
        }
    };
    request.open("GET", "../AddToCart?pid=" + productId + "&qty=" + qty, true);
    request.send();

}

function buyItNow(sellingId, qty) {

    if (qty === "") {
        // nothing to do
    } else {
        var request = new XMLHttpRequest();

        request.onreadystatechange = function () {
            if (request.readyState === 4) {
                if (request.status === 200) {
                    var response = request.responseText;

                    var inputs = document.getElementsByClassName("product-card-qty-input");
                    for (var item in inputs) {
                        inputs[item].value = "";
                    }

                    if (response === "0") {
                        // nothing to do
                    } else if (response.includes("ERROR::")) {

                        var res = response.split("ERROR::")[1];
                        openModel(res);
                    } else {

                        payment = JSON.parse(response);
                        payhere.startPayment(payment);
                    }
                }
            }
        };
        request.open("GET", "BuyItNow?sid=" + sellingId + "&qty=" + qty, false);
        request.send();
    }


}

function removeBuyItNowCart() {

    var request = new XMLHttpRequest();

    request.open("GET", "RemoveBuyItNow", true);
    request.send();

}

function generateBuyItNowInvoice() {

    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;
                if (response === "0") {
                    openModel("You have to log in, first");
                } else if (response === "1") {
                    openModel("You have no items in your cart");

                } else {

                    var w = window.open("#", "Reports");
                    w.document.write(response);

                    w.print();
                    w.close();

                }


            }
        }
    };
    request.open("GET", "GenerateBuyItNowInvoice", true);
    request.send();
}