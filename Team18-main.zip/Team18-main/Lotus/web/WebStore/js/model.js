//
//// Get the modal
var modal = document.getElementById('myModal');
//
//// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];
//
//// When the user clicks on the button, open the modal
function openM() {
    modal.style.display = "block";
}

//
//// When the user clicks on <span> (x), close the modal
span.onclick = function () {
    modal.style.display = "none";
}
//
//// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
//
//
function openModel(content) {
//
    document.getElementById("modelBodyText").innerHTML = content;

    var topic = document.getElementById("topic");
    topic.innerHTML = "Error";

    var h = document.getElementById("modalHeader");
    var f = document.getElementById("modalFooter");

    h.classList.remove("info");
    f.classList.remove("info");

    openM();
}

function openInfoModel(content) {

    var m = document.getElementById("modelBodyText").innerHTML = content;

    var topic = document.getElementById("topic");
    topic.innerHTML = "Info";

    var h = document.getElementById("modalHeader");
    var f = document.getElementById("modalFooter");

    h.classList.add("info");
    f.classList.add("info");
//    
    openM();
}