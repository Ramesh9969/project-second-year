function m() {

    var file = document.getElementById("f").files[0];
    var img = document.getElementById("profPic");
    var fileReader=new FileReader();
    
    fileReader.onload=function(){
        
        img.src=fileReader.result;
    }
    
    fileReader.readAsDataURL(file);
}