function basicSearch() {

    var category = null;
    var type = null;

    try {

        category = document.getElementById("categorySelect").value;
        //type = document.getElementById("typeSelect").value;
        type = "Any";
    } catch (e) {

    }

    var name = document.getElementById("product-name").value;
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {

        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                var count = response.split(",,,")[0];
                var content = response.split(",,,")[1];

                document.getElementById("product-count").innerHTML = count;
                document.getElementById("productContainer").innerHTML = content;

            }
        }
    };

    var parameters = "category=" + category + "&type=" + type + "&name=" + name;

    request.open("GET", "../BasicSearch?" + parameters, true);

    request.send();
}




function advancedSearch() {

    var category = null;
    var type = null;

    try {

        category = document.getElementById("categorySelect").value;
        type = document.getElementById("brandSelect").value;

    } catch (e) {

    }

    var keyword = document.getElementById("product-keyword").value;

    type = "Any";

    var priceFrom = document.getElementById("product-from").value;
    var priceTo = document.getElementById("product-to").value;
    var orderBy = document.getElementById("product-order").value;


    var parameters = "category=" + category + "&type=" + type + "&from=" + priceFrom + "&to=" + priceTo + "&order=" + orderBy + "&keyword=" + keyword;
    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                var count = response.split(",,,")[0];
                var content = response.split(",,,")[1];


                document.getElementById("product-count").innerHTML = count;
                document.getElementById("productContainer").innerHTML = content;
            }
        }

    };
    request.open("GET", "../AdvancedSearch?" + parameters, true);
    // request.open("GET", "AdvanceSearch?" + parameters, true);
    request.send();


}


function test(ch) {

    alert(ch.checked);
}

function navbarSearch() {

    var name = document.getElementById("product-name").value;

    window.location = "search_product.jsp?bsName=" + name;
}