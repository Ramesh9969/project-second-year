function openTab(evt, tabName) {
    // Declare all variables
    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

document.getElementById("defaultOpen").click();


function openVerticalTab(evt, vTabName) {
    // Declare all variables
    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("verticaltabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("verticaltablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the current tab, and add an "active" class to the link that opened the tab
    document.getElementById(vTabName).style.display = "block";
    evt.currentTarget.className += " active";
}

function loadAdminUsers() {

    var name = document.getElementById("admin-user-name").value;
    var status = document.getElementById("admin-user-status").value;
    var email = document.getElementById("admin-user-email").value;

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                document.getElementById("userMain").innerHTML = response;
            }
        }
    };

    request.open("GET", "LoadAdminUsers?name=" + name + "&status=" + status + "&email=" + email, true);
    request.send();
}

function removeUser(email) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                document.getElementById("userMain").innerHTML = response;
            }
        }
    };

    request.open("GET", "RemoveUser?email=" + email, true);
    request.send();
}

function activateUser(email) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                document.getElementById("userMain").innerHTML = response;
            }
        }
    };

    request.open("GET", "ActivateUser?email=" + email, true);
    request.send();
}

function loadAdminProducts() {

    var name = document.getElementById("admin-product-name").value;
    var status = document.getElementById("admin-product-status").value;

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                document.getElementById("productMain").innerHTML = response;
            }
        }
    };

    request.open("GET", "LoadAdminProducts?name=" + name + "&status=" + status, true);
    request.send();
}

function activateItem(idItem) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                document.getElementById("productMain").innerHTML = response;
            }
        }
    };

    request.open("GET", "ActivateItem?idItem=" + idItem, true);
    request.send();
}

function removeItem(idItem) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                document.getElementById("productMain").innerHTML = response;
            }
        }
    };

    request.open("GET", "RemoveItem?idItem=" + idItem, true);
    request.send();
}

function loadAdminSales() {

    var id = document.getElementById("admin-sale-id").value;
    var status = document.getElementById("admin-sale-status").value;
    var condition = document.getElementById("conditionSelectorProduct").value;
    var category = document.getElementById("categorySelectorProduct").value;
    var brand = document.getElementById("brandSelectorProduct").value;

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                document.getElementById("saleMain").innerHTML = response;
            }
        }
    };

    request.open("GET", "LoadAdminSales?id=" + id + "&status=" + status + "&condition=" + condition + "&category=" + category + "&brand=" + brand, true);
    request.send();
}


function activateSale(idSale) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                document.getElementById("saleMain").innerHTML = response;
            }
        }
    };

    request.open("GET", "ActivateSale?idSale=" + idSale, true);
    request.send();
}

function removeSale(idSale) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                document.getElementById("saleMain").innerHTML = response;
            }
        }
    };

    request.open("GET", "RemoveSale?idSale=" + idSale, true);
    request.send();
}

function loadLog() {
    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                var response = request.responseText;

                document.getElementById("logDiv").innerHTML = response;
            }
        }
    };

    request.open("GET", "LoadLog", true);
    request.send();
}

function clearLog() {
    document.getElementById("logDiv").innerHTML = "";
}