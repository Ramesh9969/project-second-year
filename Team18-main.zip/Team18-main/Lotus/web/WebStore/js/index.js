//window.addEventListener("beforeunload", function (e) {
//  var confirmationMessage = "\o/";
//
//  (e || window.event).returnValue = confirmationMessage; //Gecko + IE
//  return confirmationMessage;                            //Webkit, Safari, Chrome
//});




window.onbeforeunload = function () {
    var request = new XMLHttpRequest();

    request.open("GET", "DecreaseSessionCount", true);
    request.send();
};

function toShopping() {
    window.location = "search_product.jsp";
}


function closeMessage() {

    document.getElementById("msgDiv").style.display = 'none';
}