function setProductImages(fileTag) {

    var file = null;
    var img = null;

    if (fileTag.id === "f1") {
        file = document.getElementById("f1").files[0];
        img = document.getElementById("pic1");
    } else if (fileTag.id === "f2") {
        file = document.getElementById("f2").files[0];
        img = document.getElementById("pic2");
    } else {

        file = document.getElementById("f3").files[0];
        img = document.getElementById("pic3");
    }


    var fileReader = new FileReader();
    fileReader.onload = function () {

        img.src = fileReader.result;
    }

    fileReader.readAsDataURL(file);
}