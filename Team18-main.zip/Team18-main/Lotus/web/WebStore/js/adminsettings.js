
var timemilis = 0;
function calculateTime() {
    var d = new Date();
    var rtimemillis = d - timemilis;

    var millis = Math.round(((rtimemillis % 86400000) % 3600000) / 60000);

    if (millis < 60) {

        document.getElementById("runtime").innerHTML = millis + " minutes";

    } else {

        document.getElementById("runtime").innerHTML = millis + " hours";
    }
}

function suspendRadioBtn(radio) {
    if (radio.value === "no") {
        document.getElementById("suspend-hours").disabled = true;
        document.getElementById("suspend").disabled = true;
        document.getElementById("activate").disabled = false;
    } else {
        document.getElementById("suspend-hours").disabled = false;
        document.getElementById("suspend").disabled = false;
        document.getElementById("activate").disabled = true;
    }
}

function suspendApp() {

    var hours = document.getElementById("suspend-hours").value;
    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;
                document.getElementById("suspend-until").innerHTML = response;
            }
        }
    }
    request.open("GET", "SuspendApp?hours=" + hours, true);
    request.send();
}

function activateApp() {
    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {

                document.getElementById("suspend-until").innerHTML = "";
            }
        }
    }

    request.open("GET", "ActivateApp", true);
    request.send();


}

function setMessage() {

    var msg = document.getElementById("messageArea").value;

    var request = new XMLHttpRequest();
    request.open("GET", "SetMessage?msg=" + msg, true);
    request.send();
}

function removeMessage() {
    var request = new XMLHttpRequest();
    request.open("GET", "RemoveMessage", true);
    request.send();
    document.getElementById("messageArea").value = "";
}