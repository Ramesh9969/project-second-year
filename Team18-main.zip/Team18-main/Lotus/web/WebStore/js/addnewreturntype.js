function removeReturnType(rtId) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;
                document.getElementById("rt-table-div").innerHTML = response;
            }
        }
    };

    request.open("GET", "RemoveReturnType?rtId=" + rtId, true);
    request.send();
}

function addNewReturnType() {

    var rt = document.getElementById("rt").value;

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;

                document.getElementById("rt-table-div").innerHTML = response;
                document.getElementById("rt").value = null;
            }
        }
    };

    request.open("GET", "AddNewReturnType?rt=" + rt, true);
    request.send();
}
