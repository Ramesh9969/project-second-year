function removeDeliver(delId) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;
                document.getElementById("del-table-div").innerHTML = response;
            }
        }
    };

    request.open("GET", "RemoveDeliver?delId=" + delId, true);
    request.send();
}

function addNewDelivery() {

    var name = document.getElementById("del-name").value;
    var no = document.getElementById("del-no").value;

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;

                document.getElementById("del-table-div").innerHTML = response;
                document.getElementById("del-name").value = null;
                document.getElementById("del-no").value = null;
            }
        }
    };

    request.open("GET", "AddDeliver?name=" + name + "&no=" + no, true);
    request.send();
}
