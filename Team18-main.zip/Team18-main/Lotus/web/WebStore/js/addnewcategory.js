function removeCategory(catId) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;
                document.getElementById("cat-table-div").innerHTML = response;
            }
        }
    };

    request.open("GET", "RemoveCategory?catId=" + catId, true);
    request.send();
}

function addNewCategory() {

    var cat = document.getElementById("cat").value;

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                var response = request.responseText;

                document.getElementById("cat-table-div").innerHTML = response;
                document.getElementById("cat").value=null;
            }
        }
    };

    request.open("GET", "AddCategory?cat=" + cat, true);
    request.send();
}
