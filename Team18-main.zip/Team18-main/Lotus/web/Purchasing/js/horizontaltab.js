
function openHorizontalTab(evt, vTabName, tablinks, tabcontent) {
    var tablinks_children = document.getElementById(tablinks).children;
    var tabcontent_children = document.getElementById(tabcontent).children;

    for (var i = 0; i < tabcontent_children.length; i++) {

        if ((tabcontent_children[i].className.search("horizontaltabcontent")) >= 0) {
            tabcontent_children[i].style.display = "none";
        }
    }
    tablinks = document.getElementsByClassName("horizontaltablinks");
    for (var j = 0; j < tablinks_children.length; j++) {

        if ((tablinks_children[j].className.search("horizontaltablinks")) >= 0) {
            tablinks_children[j].className = tablinks_children[j].className.replace(" active", "");
        }
    }
    document.getElementById(vTabName).style.display = "block";
    evt.currentTarget.className += " active";
}
