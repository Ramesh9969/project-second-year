function addToTable() {
    var id = document.getElementById("sid");
    var name = document.getElementById("name");
    var qty = document.getElementById("qty");
    var bprice = document.getElementById("bprice");
    var sprice = document.getElementById("sprice");

    if (sprice.value < bprice.value) {
        openErrorModel("Selling price cannot be less than buying price");
    } else {
        var total = qty.value * bprice.value;

        var table = document.getElementById("p-stockTable");
        var tr = document.createElement("tr");
        tr.innerHTML = "<tr><td>" + id.value + "</td><td>" + name.innerHTML + "</td><td>" + qty.value + "</td><td>" + bprice.value + "</td><td>" + sprice.value + "</td><td class='total'>" + total + "</td></tr>";
        table.appendChild(tr);

        id.value = name.innerHTML = qty.value = bprice.value = sprice.value = null;

        setTotal();
    }
}

function setTotal() {
    var t = document.getElementsByClassName("total");
    var totalCount = 0;

    for (var i = 0; i < t.length; i++) {
        totalCount += parseInt(t[i].innerHTML);
    }

    document.getElementById("tprice").innerHTML = totalCount;

    setNetAmount();
}

function setNetAmount() {
    var totalPrice = document.getElementById("tprice").innerHTML;
    if (totalPrice !== "") {
        var discount = document.getElementById("discount").value;

        var netAmount = totalPrice - discount;

        if (netAmount < 0) {
            netAmount = 0;
        }
        document.getElementById("netamount").innerHTML = netAmount;
    }

}

function setBalance() {
    var netamount = document.getElementById("netamount").innerHTML;
    var payment = document.getElementById("payment").value;

    if (payment > 0 && netamount > 0) {

        var balance = payment - netamount;

        if (balance < 0) {
            openErrorModel("Balance cannot be less than zero");
            document.getElementById("saveButton").disabled = true;
        } else {
            document.getElementById("balance").innerHTML = balance;
        }
    }

}