/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

/**
 *
 * @author Rajitha Yasasri
 */
public class DB {

    private static Connection con;

    private static void setUpConnection() throws Exception {

        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3307/lotus", "root", "123");
    }

    public static Connection getConnection() throws Exception {

        if (con == null) {
            setUpConnection();
        }
        return con;
    }

    public static void iud(String text) throws Exception {
        if (con == null) {
            setUpConnection();
        }

        con.createStatement().executeUpdate(text);
    }
    
    public static ResultSet search(String text)throws Exception{
        if (con==null) {
            setUpConnection();
        }
        
        return con.createStatement().executeQuery(text);
    }
}
