/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import ORM.Cartitem;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.State;

/**
 *
 * @author Rajitha Yasasri
 */
public class SearchCart extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try {

            String name = req.getParameter("search");

            List<Cartitem> cartItems = new ArrayList<>();

            if (req.getSession().getAttribute("customer_email") != null) {
                // db cart

                String customer = req.getSession().getAttribute("customer_email").toString();
                // Set<Cart> cartItems = customer.getCarts();

                String customer_email = (String) req.getSession().getAttribute("customer_email");

                ResultSet search = db.DB.search("SELECT * FROM cartitem c INNER JOIN selling s INNER JOIN productstock ps INNER JOIN product p ON s.idselling=c.selling_idselling AND ps.idproductstock=s.productstock_idproductstock AND ps.product_idproduct=p.idproduct WHERE customer_email='" + customer_email + "' AND c.status_idstatus='" + model.State.getACTIVE() + "' AND p.name LIKE '%"+name+"%'");

                while (search.next()) {
                    Cartitem c = new Cartitem();

                    c.setDate(search.getDate("date"));
                    c.setIdcartitem(search.getInt("idcartitem"));
                    c.setQty(search.getDouble("qty"));
                    c.setIdSelling(search.getInt("idselling"));
                    c.setStatus(model.State.getACTIVE());

                    cartItems.add(c);

                }

            } else if (req.getSession().getAttribute("cartItemList") != null) {
                // session cart
                cartItems = (ArrayList<Cartitem>) req.getSession().getAttribute("cartItemList");
                // to do
            }

            req.setAttribute("cartItems", cartItems);
            req.getRequestDispatcher("WebStore/cart_items.jsp").forward(req, resp);

        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("error.jsp");
        }
    }

}
