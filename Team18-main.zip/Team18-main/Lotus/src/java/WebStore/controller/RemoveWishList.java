/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.State;

/**
 *
 * @author Rajitha Yasasri
 */
public class RemoveWishList extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try {

            String wishListId = req.getParameter("wid");

            ResultSet search = db.DB.search("SELECT * FROM wishlistitem WHERE idwishlistitem='" + wishListId + "'");
            if (search.next()) {
                if (search.getInt("status_idstatus") == State.getACTIVE()) {
                    db.DB.iud("UPDATE wishlistitem SET status_idstatus='" + State.getREMOVED() + "' WHERE idwishlistitem='" + search.getInt("idwishlistitem") + "'");
                }

            } else {
                req.setAttribute("wishlist-error", "Invalid wish list item");
                req.getRequestDispatcher("wishlist.jsp").forward(req, resp);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
