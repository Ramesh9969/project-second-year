/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import ORM.Cartitem;
import ORM.Invoice;
import ORM.InvoiceItem;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Rajitha Yasasri
 */
public class SearchPurchases extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String name = req.getParameter("search");

            if (req.getSession().getAttribute("customer_email") != null) {

                String cust = req.getSession().getAttribute("customer_email").toString();
                List<InvoiceItem> invoiceItems = new ArrayList<>();

                ResultSet search = db.DB.search("SELECT * FROM invoiceitem it INNER JOIN productstock ps INNER JOIN product p INNER JOIN invoice i INNER JOIN cartitem c INNER JOIN Selling s ON it.invoice_idinvoice=i.idinvoice AND it.cartitem_idcartitem=c.idcartitem AND c.selling_idselling=s.idselling AND ps.idproductstock=s.productstock_idproductstock AND p.idproduct=ps.idproductstock WHERE i.customer_email='" + cust + "' AND p.name LIKE '%" + name + "%' ORDER BY it.status_idstatus  ");

                while (search.next()) {
                    InvoiceItem it = new InvoiceItem();
                    it.setIdInvoiceItem(search.getInt("it.idinvoiceitem"));
                    it.setStatus_idstatus(search.getInt("it.status_idstatus"));

                    Cartitem c = new Cartitem();
                    c.setDate(search.getDate("c.date"));
                    c.setIdSelling(search.getInt("c.selling_idselling"));
                    c.setQty(search.getDouble("c.qty"));
                    c.setIdcartitem(search.getInt("c.idcartitem"));
                    c.setStatus(search.getInt("c.status_idstatus"));

                    it.setCartitem(c);

                    Invoice i = new Invoice();
                    i.setDate(search.getDate("i.date"));
                    i.setIdInvoice(search.getInt("i.idinvoice"));
                    i.setPayment(search.getDouble("i.payment"));

                    it.setInvoice(i);

                    invoiceItems.add(it);
                }

                req.setAttribute("invoiceItems", invoiceItems);
                req.getRequestDispatcher("WebStore/purchaseitems.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("WebStore/error.jsp");
        }
    }

}
