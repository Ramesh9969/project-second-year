/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.State;

/**
 *
 * @author Rajitha Yasasri
 */
public class MarkAsReceived extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try {
            String id = req.getParameter("id");
            //System.out.println(id);

            if (req.getSession().getAttribute("customer_email") != null) {
                String cust = req.getSession().getAttribute("customer_email").toString();

                ResultSet search = db.DB.search("SELECT * FROM invoiceitem it INNER JOIN invoice i ON i.idinvoice=it.invoice_idinvoice WHERE it.idinvoiceitem='" + id + "' AND i.customer_email='" + cust + "' AND it.status_idstatus='" + State.getSHIPPED() + "'"); // to check whether the id is valid and belongs to the currently logged customer

                if (search.next()) {
                    db.DB.iud("UPDATE invoiceitem SET status_idstatus='" + State.getRECEIVED() + "' WHERE idinvoiceitem='" + id + "'");
                } else {
                    // error but nothing to do
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("WebStore/error.jsp");
        }
    }

}
