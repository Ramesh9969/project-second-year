/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import ORM.SignUpCustomer;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.DefaultItems;
import model.State;
import model.Validator;

/**
 *
 * @author Rajitha Yasasri
 */
public class CheckSignUp extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try {
            String usercode = req.getParameter("code");
            HttpSession session = req.getSession();

            if (Validator.isValidNumber(usercode)) {

                String signupCode = (String) session.getAttribute("signup-code");
                Calendar calendar = (Calendar) session.getAttribute("signup-expire-time");

                long expireTime = calendar.getTimeInMillis();

                Calendar instance = Calendar.getInstance();
                if (Integer.parseInt(usercode) == Integer.parseInt(signupCode) && instance.getTimeInMillis() < expireTime) {

                    // remove attributes signup-code, signup-expire-time and signup-customer
                    session.removeAttribute("signup-code");
                    session.removeAttribute("signup-expire-time");
                    SignUpCustomer cust = (SignUpCustomer) session.getAttribute("signup-customer");
                    session.setAttribute("customer_email", cust.getEmail());

                    session.removeAttribute("signup-customer");

                    Date d = new Date();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    String format = sdf.format(d);
                    db.DB.iud("INSERT INTO customer (fname,email,join_date,status_idstatus,password,gender_idgender,picture_idpicture)VALUES ('" + cust.getFname() + "','" + cust.getEmail() + "','" + format + "','" + State.getACTIVE() + "','" + cust.getPassword() + "','" + DefaultItems.getDefaultGenderType() + "','" + DefaultItems.getDefaultProfileImageID() + "')");

                    resp.sendRedirect("profile.jsp");
                } else {
                    System.out.println("invalid or expired code");
                    req.setAttribute("entersignupcode-error", "invalid or expired code");
                    req.getRequestDispatcher("entersignupcode.jsp").forward(req, resp);

                }
            } else {
                System.out.println("invalid code ");
                req.setAttribute("entersignupcode-error", "invalid code");
                req.getRequestDispatcher("entersignupcode.jsp").forward(req, resp);
            }

        } catch (Exception e) {
         
            e.printStackTrace();
            resp.sendRedirect("error.jsp");
        }
    }

}
