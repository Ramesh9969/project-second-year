/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.State;

/**
 *
 * @author Rajitha Yasasri
 */
public class Login extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try {
            String email = req.getParameter("email");
            String pass = req.getParameter("pass");
            //System.out.println("Login");
            PrintWriter writer = resp.getWriter();
            HttpSession session = req.getSession();
          
            if (!email.isEmpty() && !pass.isEmpty()) {

                ResultSet search = db.DB.search("SELECT * FROM customer WHERE email='" + email + "'AND password='" + pass + "' AND status_idstatus='" + State.getACTIVE() + "'");

                if (search.next()) {

                    req.getSession().setAttribute("customer_email", email);
                    req.getRequestDispatcher("SyncCarts").forward(req, resp);

                } else {
                    session.setAttribute("login-error", "invalid-login");
                    resp.sendRedirect("WebStore/login.jsp");
                }
            } else {
                session.setAttribute("login-error", "invalid-login");
                resp.sendRedirect("WebStore/login.jsp");
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("WebStore/error.jsp");
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // super.doGet(req, resp); //To change body of generated methods, choose Tools | Templates.
    }

}
