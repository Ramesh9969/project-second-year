/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.DefaultItems;
import model.State;
import model.Validator;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 *
 * @author Rajitha Yasasri
 */
public class SaveUser extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        HttpSession session = req.getSession();

        try {
            String email = (String) session.getAttribute("customer_email");

            String fname = null;
            String lname = null;
            String pass = null;
            String repass = null;
            String mobile = null;
            String gender = null;

            String address1 = null;

            String company = null;

            String fileName = null;

            boolean isImageChanged = false;

            DiskFileItemFactory diff = new DiskFileItemFactory();
            ServletFileUpload sfu = new ServletFileUpload(diff);
            List<FileItem> fiList = sfu.parseRequest(req);

            for (FileItem fileItem : fiList) {
                if (fileItem.isFormField()) {

                    if (fileItem.getFieldName().equals("fname")) {
                        fname = fileItem.getString();
                    }
                    if (fileItem.getFieldName().equals("lname")) {
                        lname = fileItem.getString();
                    }
                    if (fileItem.getFieldName().equals("pass")) {
                        pass = fileItem.getString();
                    }
                    if (fileItem.getFieldName().equals("repass")) {
                        repass = fileItem.getString();
                    }
                    if (fileItem.getFieldName().equals("mobile")) {
                        mobile = fileItem.getString();
                    }
                    if (fileItem.getFieldName().equals("gender")) {
                        gender = fileItem.getString();
                    }
                    if (fileItem.getFieldName().equals("address1")) {
                        address1 = fileItem.getString();
                    }
                    if (fileItem.getFieldName().equals("company")) {
                        company = fileItem.getString();
                    }
                } else {
                    if (fileItem.getSize() != 0) {
                        String realPath = getServletContext().getRealPath("");

                        ResultSet picSearch = db.DB.search("SELECT picturepath FROM picture WHERE idpicture=(SELECT picture_idpicture FROM customer WHERE email='" + email + "')");
                        String pic = null;
                        if (picSearch.next()) {
                            pic = picSearch.getString(1);
                        }
                        if (!picSearch.getString(1).equals(DefaultItems.getDefaultProfileImagePath())) {
                            File currentFile = new File(realPath + File.separator + "WebStore" + File.separator + "img" + File.separator + "profile-pics" + File.separator + pic);
                            currentFile.delete();
                        }

                        fileName = System.currentTimeMillis() + ".png";
                        String filePath = realPath + File.separator + "WebStore" + File.separator + "img" + File.separator + "profile-pics" + File.separator + fileName;

                        File newFile = new File(filePath);
                        fileItem.write(newFile);

                        isImageChanged = true;
                    }

                }
            }

            if (Validator.isValidStringMany(fname, lname) && pass.equals(repass) && Validator.isValidPhoneNumber(mobile) && Validator.isValidAddressString(address1)) {

                if (isImageChanged) {
                    db.DB.iud("INSERT INTO picture (picturepath) VALUES ('" + fileName + "')");
                    ResultSet search = db.DB.search("SELECT MAX(idpicture) FROM picture");
                    int picId = DefaultItems.getDefaultProfileImageID();
                    if (search.next()) {
                        picId = search.getInt(1);
                    }
                    db.DB.iud("UPDATE customer SET fname='" + fname + "', lname='" + lname + "',gender_idgender='" + gender + "',mobile='" + mobile + "',company_name='" + company + "',address='" + address1 + "',password='" + pass + "',picture_idpicture='" + picId + "' WHERE email='" + email + "'");

                } else {
                    db.DB.iud("UPDATE customer SET fname='" + fname + "', lname='" + lname + "',gender_idgender='" + gender + "',mobile='" + mobile + "',company_name='" + company + "',address='" + address1 + "',password='" + pass + "' WHERE email='" + email + "'");
                }
            } else {
                session.setAttribute("user-save-error", "Invalid data");
            }
            resp.sendRedirect("WebStore/profile.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("WebStore/error.jsp");
        }

    }

}
