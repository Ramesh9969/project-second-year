/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.State;

/**
 *
 * @author Rajitha Yasasri
 */
public class AddToWishList extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        PrintWriter out = resp.getWriter();
        try {
            
            String cust = req.getSession().getAttribute("customer_email").toString();
            String sid = req.getParameter("sid");
            
            if (cust == null) {
                
                out.write("You must be logged in to add a item to the wish list");
                
            } else {
                
                ResultSet search = db.DB.search("SELECT * FROM selling WHERE idselling='" + sid + "'");
                
                if (search.next()) {
                    
                    ResultSet wishListSearch = db.DB.search("SELECT * FROM wishlistitem WHERE selling_idselling='" + sid + "'");
                    
                    if (wishListSearch.next()) {

                        // already exist. so the status should be changed
                        if (wishListSearch.getInt("status_idstatus") == State.getREMOVED()) {
                            db.DB.iud("UPDATE wishlistitem SET status_idstatus='" + State.getACTIVE() + "' WHERE idwishlistitem='" + wishListSearch.getString("idwishlistitem") + "'");
                            out.write(Integer.toString(1));
                        } else {
                            
                            db.DB.iud("UPDATE wishlistitem SET status_idstatus='" + State.getREMOVED() + "' WHERE idwishlistitem='" + wishListSearch.getString("idwishlistitem") + "'");
                            
                            out.write(Integer.toString(0));
                        }
                        
                    } else {
                        
                        Date d=new Date();
                        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
                        String format = sdf.format(d);
                        db.DB.iud("INSERT INTO wishlistitem (date,customer_email,selling_idselling,status_idstatus) VALUES ('" + format + "','" + cust + "','" + sid + "','" + State.getACTIVE() + "')");
                        
                        out.write(Integer.toString(1));
                    }
                } else {
                    out.write("error");
                    return;
                }
                
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.write("Error");
        }
    }
    
}
