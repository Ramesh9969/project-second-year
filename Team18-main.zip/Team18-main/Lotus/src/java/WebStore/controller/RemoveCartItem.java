/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import ORM.Cartitem;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.State;
import model.Validator;

/**
 *
 * @author Rajitha Yasasri
 */
public class RemoveCartItem extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        try {
            
            String cid = req.getParameter("cid");
            
            HttpSession httpSession = req.getSession();
            Object customer = httpSession.getAttribute("customer_email");
            
            PrintWriter out = resp.getWriter();
            
            if (customer == null) {

                // session cart
                System.out.println("session cart");
                ArrayList<Cartitem> cartItemList = (ArrayList<Cartitem>) httpSession.getAttribute("cartItemList");
                
                if (Validator.isValidNumber(cid)) {
                    // nothing to do
                } else {
                    out.write("Invalid cart id");
                    return;
                }
                
                Cartitem removeItem = null;
                for (Cartitem cartitem : cartItemList) {
                    if (cartitem.getIdcartitem() == Integer.parseInt(cid)) {
                        removeItem = cartitem;
                        break;
                    }
                }
                
                if (removeItem == null) {
                    out.write("Invalid cart id");
                } else {
                    cartItemList.remove(removeItem);
                    out.write("1");
                }
            } else {
                // db cart
                String cust = customer.toString();
                
                ResultSet search = db.DB.search("SELECT * FROM cartitem WHERE idcartitem='" + cid + "' AND customer_email='" + cust + "'");
                
                if (search.next()) {
                    db.DB.iud("UPDATE cartitem SET status_idstatus='" + State.getREMOVED() + "' WHERE idcartitem='" + cid + "'");
                    
                    out.write("1");
                } else {
                    
                    System.out.println("invalid cart id");
                    out.write("invalid cart id");
                }
                
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("error.jsp");
        }
    }
    
}
