/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import ORM.SignUpCustomer;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.State;
import static model.Validator.*;

/**
 *
 * @author Rajitha Yasasri
 */
public class SignUp extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        HttpSession session = req.getSession();
        try {

            String fname = req.getParameter("fname");
            String email = req.getParameter("email");
            String pass = req.getParameter("pass");
            String repass = req.getParameter("repass");
            PrintWriter out = resp.getWriter();
            if (fname.isEmpty() || email.isEmpty() || pass.isEmpty() || repass.isEmpty()) {
                out.write("Invalid details");
            } else {

                if (isValidEmail(email) && isValidString(fname) && isNotEmptyText(pass) && (pass.equals(repass))) {

                    ResultSet search = db.DB.search("SELECT * FROM customer WHERE email='" + email + "'");

                    if (search.next()) {
                        req.setAttribute("signUp-error", "Cannot sign up to an existing email");
                        req.getRequestDispatcher("signup.jsp").forward(req, resp);

                    } else {
                        SignUpCustomer cust = new SignUpCustomer();
                        cust.setEmail(email);
                        cust.setFname(fname);
                        cust.setPassword(pass);

                        HttpSession s = req.getSession();

                        s.setAttribute("signup-customer", cust);
                        req.getRequestDispatcher("../SendSignupEmail").forward(req, resp);
                    }

                } else {
                    req.setAttribute("signUp-error", "invalid credentials");
                    req.getRequestDispatcher("signup.jsp").forward(req, resp);

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("signUp-error", "error");
            req.getRequestDispatcher("signup.jsp").forward(req, resp);
        }
    }

}
