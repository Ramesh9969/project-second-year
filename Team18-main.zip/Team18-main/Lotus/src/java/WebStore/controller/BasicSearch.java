/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import ORM.Selling;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.State;
import model.Validator;

/**
 *
 * @author Rajitha Yasasri
 */
public class BasicSearch extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try {

            String category = req.getParameter("category");
            String type = req.getParameter("type");
            String name = req.getParameter("name");

            if (Validator.isEmptyText(name)) {
                name = "";
            }
            if (Validator.isEmptyText(category)) {
                category = "Any";
            }
            if (Validator.isEmptyText(type)) {
                type = "Any";
            }

//            System.out.println(category);
//            System.out.println(brand);
//            System.out.println(name);
            ArrayList<Selling> sellingList = new ArrayList<Selling>();

            String queryPart = "SELECT * FROM selling s INNER JOIN productstock ps INNER JOIN product p INNER JOIN category c INNER JOIN `type` t INNER JOIN unit u ON s.productstock_idproductstock=ps.idproductstock AND ps.product_idproduct=p.idproduct AND p.category_idcategory=c.idcategory AND p.type_idtype=t.idtype AND p.unit_idunit=u.idunit WHERE s.status_idstatus='" + State.getACTIVE() + "'";

            if (!category.equals("Any")) {

                queryPart += " AND c.description='" + category + "'";
            }

            if (!type.equals("Any")) {
                queryPart += " AND t.type='" + type + "'";
            }

            queryPart += " AND p.name LIKE '%" + name + "%'";
//System.out.println(queryPart);
            ResultSet search = db.DB.search(queryPart);

            while (search.next()) {

                int idSelling = search.getInt("idselling");

                Selling s = new Selling();
                s.setIdSelling(search.getInt("idSelling"));
                s.setDate(search.getDate("date"));
                s.setQty(search.getDouble("qty"));
                s.setUnitPrice(search.getDouble("unitprice"));
                s.setDescription(search.getString("s.description"));
                s.setDeliveryCharge(search.getDouble("deliverycharge"));
                s.setIdProduct(search.getInt("product_idproduct"));
                s.setName(search.getString("name"));
                s.setCategory(search.getString("c.description"));
                s.setType(search.getString("type"));
                s.setUnit(search.getString("unit"));

                String[] ar = new String[3];
                ResultSet search1 = db.DB.search("SELECT picturepath FROM picture p INNER JOIN selling_has_picture shp ON p.idpicture=shp.picture_idpicture WHERE shp.selling_idselling='" + idSelling + "'");

                int i = 0;
                while (search1.next()) {
                    ar[i] = search1.getString(1);
                    ++i;
                }

                s.setPics(ar);

                sellingList.add(s);
            }
            req.setAttribute("sellings", sellingList);
            req.getRequestDispatcher("WebStore/loadproducts.jsp").forward(req, resp);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
