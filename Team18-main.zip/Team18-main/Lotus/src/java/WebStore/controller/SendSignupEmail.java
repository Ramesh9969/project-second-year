/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import ORM.SignUpCustomer;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Utility;

/**
 *
 * @author Rajitha Yasasri
 */
public class SendSignupEmail extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try {
            HttpSession httpSession = req.getSession();

            SignUpCustomer cust = (SignUpCustomer) req.getSession().getAttribute("signup-customer");

            String to = cust.getEmail();
            String subject = "Sign up email";

            Properties p = System.getProperties();
            p.put("mail.smtp.host", "smtp.gmail.com");
            p.put("mail.smtp.port", "587");
            p.put("mail.smtp.auth", "true");
            p.put("mail.smtp.starttls.enable", "true");
            p.put("mail.smtp.ssl.trust", "smtp.gmail.com");

            Authenticator authenticator = new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {

                    PasswordAuthentication authentication = new PasswordAuthentication("rajithayasasri123@gmail.com", "19980420S"); // <- username, password

                    return authentication;
                }

            };

            Session session = Session.getInstance(p, authenticator);

            MimeMessage message = new MimeMessage(session);

            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setFrom(new InternetAddress("rajithayasasri123@gmail.com"));
            message.setSubject(subject);

            String code = Utility.generateRandomNumber();

            //calculating the valid time period
            Calendar instance = Calendar.getInstance();
            long afterFiveMins = instance.getTimeInMillis() + 5 * 60 * 1000;  // 5 minutes

            instance.setTimeInMillis(afterFiveMins);

            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a");
            String dateString = sdf.format(instance.getTime());

            String htmlContent = "<h3 style=\"text-decoration: underline; font-family: 'Century Gothic'\">Welcome!!</h3>\n"
                    + "        <span style=\"font-family: 'Century Gothic';\">Your sign up code is:<b>" + code + "</b>. The code will be expired at " + dateString + "</span>";
            message.setContent(htmlContent, "text/html; charset=utf-8");

            Transport.send(message);

            httpSession.setAttribute("signup-code", code);
            httpSession.setAttribute("signup-expire-time", instance);

            resp.sendRedirect("entersignupcode.jsp");
        } catch (Exception e) {
            System.out.println("mail sent");
            e.printStackTrace();
            resp.sendRedirect("error.jsp");
        }
    }

}
