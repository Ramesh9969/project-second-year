/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import ORM.Cartitem;
import java.io.IOException;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.State;
import model.Validator;

/**
 *
 * @author Rajitha Yasasri
 */
public class AddToCart extends HttpServlet {

    private static int cid = 1;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try {

            String sellingId = req.getParameter("pid");
            String qty = req.getParameter("qty");

            // System.out.println(qty);
            //System.out.println(sellingId);
            if (!Validator.isValidNumber(qty)) {
                resp.getWriter().write("ERROR::enter a valid qty!");
                return;
            }

            Object customer = req.getSession().getAttribute("customer_email");

            ResultSet sellingSearch = db.DB.search("SELECT * FROM Selling WHERE idselling='" + sellingId + "' AND status_idstatus='" + State.getACTIVE() + "'");
            if (sellingSearch.next()) {

                Date d = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String dateFormat = sdf.format(d);
                if (customer != null) {

                    String cust = customer.toString();
                    // db cart
                    ResultSet cartSearch = db.DB.search("SELECT * FROM cartitem WHERE selling_idselling='" + sellingId + "' AND (status_idstatus='" + State.getACTIVE() + "' OR status_idstatus='" + State.getREMOVED() + "')");

                    if (cartSearch.next()) {
                        // already added

                        double sellingQty = 0.0;
                        double cartQty = 0.0;
                        double requiredQty = 0.0;
                        double newQty = 0.0;

                        if (cartSearch.getInt("status_idstatus") == State.getACTIVE()) {
                            sellingQty = sellingSearch.getDouble("qty");
                            cartQty = cartSearch.getDouble("qty");
                            requiredQty = Double.parseDouble(qty);

                            if (sellingQty >= cartQty + requiredQty) {
                                newQty = cartQty + requiredQty;

                                db.DB.iud("UPDATE cartitem SET qty='" + newQty + "', date='" + dateFormat + "' WHERE idcartitem='" + cartSearch.getString("idcartitem") + "'");

                                resp.getWriter().write("updated cart");
                            } else {
                                resp.getWriter().write("ERROR::Out of Stock");

                            }
                        } else {
                            // Removed State
                            sellingQty = sellingSearch.getDouble("qty");
                            requiredQty = Double.parseDouble(qty);

                            if (sellingQty >= requiredQty) {

                                newQty = cartQty + requiredQty;
                                db.DB.iud("UPDATE cartitem SET status_idstatus='" + State.getACTIVE() + "', qty='" + newQty + "', date='" + dateFormat + "' WHERE idcartitem='" + cartSearch.getString("idcartitem") + "'");

                                resp.getWriter().write("updated cart");
                            } else {
                                resp.getWriter().write("ERROR::Out of Stock");
                            }
                        }

                    } else {

                        //new item
                        if (sellingSearch.getDouble("qty") >= Integer.parseInt(qty)) {

                            //stock available
                            db.DB.iud("INSERT INTO cartitem (date,qty,customer_email,selling_idselling,status_idstatus) VALUES ('" + dateFormat + "','" + qty + "','" + cust + "','" + sellingSearch.getInt("idselling") + "','" + State.getACTIVE() + "')");

                            resp.getWriter().write("Added to cart");
                        } else {
                            resp.getWriter().write("ERROR::Out of Stock");
                        }
                    }

                } else {
                    //session cart
                    HttpSession httpSession = req.getSession();

                    Cookie ck = new Cookie("JSESSIONID", req.getSession().getId());
                    ck.setMaxAge(3600 * 24);
                    resp.addCookie(ck);

                    if (httpSession.getAttribute("cartItemList") != null) {
// session cart list found
                        ArrayList<Cartitem> cartItemList = (ArrayList<Cartitem>) httpSession.getAttribute("cartItemList");

                        Cartitem cartFound = null;
                        for (Cartitem cart : cartItemList) {
                            if (cart.getIdSelling() == sellingSearch.getInt("idselling")) {
                                cartFound = cart;
                                break;
                            }
                        }

                        if (cartFound != null) {

                            // already found in session cart
                            if (sellingSearch.getDouble("qty") >= (cartFound.getQty() + Double.parseDouble(qty))) {

                                cartFound.setQty(cartFound.getQty() + Integer.parseInt(qty));
                                resp.getWriter().write("cart updated");
                            } else {
                                //quantity out of stock
                                resp.getWriter().write("ERROR::Quantity out of stock");
                            }
                        } else {

// item not found in session cart
                            if (sellingSearch.getDouble("qty") >= Double.parseDouble(qty)) {
                                cid++;

                                Cartitem cart = new Cartitem();
                                cart.setIdcartitem(cid);
                                cart.setDate(new Date());
                                cart.setIdSelling(sellingSearch.getInt("idselling"));
                                cart.setQty(Double.parseDouble(qty));
                                cart.setStatus(State.getACTIVE());
                                cartItemList.add(cart);
                                httpSession.setAttribute("cartItemList", cartItemList);

                                resp.getWriter().write("Item Added");
                            } else {
                                resp.getWriter().write("ERROR::Quantity out of stock");
                            }

                        }
                    } else {
// no session cart item list

                        if (sellingSearch.getDouble("qty") >= Double.parseDouble(qty)) {

                            ArrayList<Cartitem> cartItemList = new ArrayList<>();
                            Cartitem cart = new Cartitem();
                            cart.setIdcartitem(cid);
                            cart.setDate(new Date());
                            cart.setIdSelling(sellingSearch.getInt("idselling"));
                            cart.setQty(Double.parseDouble(qty));
                            cart.setStatus(State.getACTIVE());
                            cartItemList.add(cart);
                            httpSession.setAttribute("cartItemList", cartItemList);

                            resp.getWriter().write("Item Added");

                        } else {

                            resp.getWriter().write("ERROR::Quantity Out of Stock");
                        }
                    }

                }
            } else {
                resp.getWriter().write("ERROR::ERROR");
            }

        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().write("ERROR::ERROR");
        }
    }

}
