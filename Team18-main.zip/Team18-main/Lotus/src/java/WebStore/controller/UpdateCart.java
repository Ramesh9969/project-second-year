/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import ORM.Cartitem;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.State;
import model.Validator;

/**
 *
 * @author Rajitha Yasasri
 */
public class UpdateCart extends HttpServlet {
    
    private static int cid = 1;
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        PrintWriter out = resp.getWriter();
        try {
            
            HttpSession httpSession = req.getSession();
            
            String cid = req.getParameter("cid");
            String q = req.getParameter("qty");
            
            double qty = Double.parseDouble(q);
            
            if (!Validator.isValidNumber(q)) {
                return;
            }
            if (qty <= 0) {
                out.write("qty cannot be zero or below");
                return;
            }
            
            Object customer = httpSession.getAttribute("customer_email");

//            System.out.println(cid);
//            System.out.println(qty);
            if (customer != null) {
                String cust = customer.toString();
                //db cart

                ResultSet search = db.DB.search("SELECT * FROM cartitem c INNER JOIN selling s ON c.selling_idselling=s.idselling WHERE c.idcartitem='" + cid + "' AND c.customer_email='" + cust + "' AND c.status_idstatus='" + State.getACTIVE() + "'");
                if (search.next()) {
                    
                    if (search.getDouble("s.qty") >= qty) {
                        db.DB.iud("UPDATE cartitem SET qty='" + qty + "' WHERE idcartitem='" + search.getInt("idcartitem") + "'");
                        out.write("qty updated");
                        
                    } else {
                        out.write("out of stock");
                    }
                } else {
                    // nothing is changed and no error is shown
                }
            } else {
                // session cart
                // System.out.println("session cart");
                ArrayList<Cartitem> cartItemList = (ArrayList<Cartitem>) httpSession.getAttribute("cartItemList");
                
                if (cartItemList == null) {
                    out.write("error");
                    
                } else {
                    
                    for (Cartitem cartitem : cartItemList) {
                        if (cartitem.getIdcartitem() == Integer.parseInt(cid)) {
                            
                            ResultSet sellingQtySearch = db.DB.search("SELECT qty FROM selling WHERE idselling='" + cartitem.getIdSelling() + "'");
                            sellingQtySearch.next();
                            if (sellingQtySearch.getDouble(1) >= qty) {
                                
                                cartitem.setQty(qty);
                                out.write("qty updated");
                            } else {
                                out.write("out of stock");
                            }
                        }
                    }
                    // if the requested cartitem is not in the cart item list, no error is shown and nothing changed
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            out.write("error");
        }
    }
    
}
