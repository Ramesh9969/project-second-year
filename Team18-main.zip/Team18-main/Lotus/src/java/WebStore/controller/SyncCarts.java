/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebStore.controller;

import ORM.Cartitem;
import java.io.IOException;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.State;

/**
 *
 * @author Rajitha Yasasri
 */
public class SyncCarts extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try {
            HttpSession httpSession = req.getSession();
            ArrayList<Cartitem> cartItemList = (ArrayList<Cartitem>) httpSession.getAttribute("cartItemList");

            //System.out.println("sync carts");
            if (cartItemList == null) {
                // System.out.println("null");
                // nothing to do
            } else {
                //System.out.println("not null");

                String cust = (String) httpSession.getAttribute("customer_email");
                for (Cartitem cartitem : cartItemList) {
                    //System.out.println(cartitem.getSelling().getIdselling());

                    ResultSet search = db.DB.search("SELECT * FROM cartitem WHERE customer_email='" + cust + "' AND selling_idselling='" + cartitem.getIdSelling() + "' AND status_idstatus='" + State.getACTIVE() + "'");

                    Date d = new Date();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    String format = sdf.format(d);

                    ResultSet qtySearch = db.DB.search("SELECT qty FROM selling WHERE idselling='" + cartitem.getIdSelling() + "'");
                    qtySearch.next();
                    if (search.next()) {

                        // System.out.println("not empty" + cartitem.getSelling().getStock().getItemHasCondition().getItem().getName());
                        double currentQty = search.getDouble("qty");
                        double newQty = currentQty + cartitem.getQty();

                        if (newQty > qtySearch.getDouble(1)) {
                            newQty = qtySearch.getDouble(1);
                            //System.out.println("new qty");
                        } else {
                            // do nothing
                        }
                        //System.out.println(newQty);

                        db.DB.iud("UPDATE cartitem SET qty='" + newQty + "', date='" + format + "' WHERE idcartitem='" + search.getString("idcartitem") + "'");

                    } else {
                        //System.out.println("empty" + cartitem.getSelling().getStock().getItemHasCondition().getItem().getName());

                        double qty = 0.0;
                        if (cartitem.getQty() > qtySearch.getDouble(1)) {
                            qty = qtySearch.getDouble(1);
                            // System.out.println("if; cartiem qty> selling qty");
                        } else {
                            qty = cartitem.getQty();
                        }
                        //System.out.println(qty);

                        db.DB.iud("INSERT INTO cartitem (date,qty,customer_email,status_idstatus,selling_idselling) VALUES('" + format + "','" + qty + "','" + cust + "','" + State.getACTIVE() + "','" + cartitem.getIdSelling() + "')");
                    }

                }

            }
            resp.sendRedirect("WebStore/index.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("WebStore/error.jsp");
        }

    }

}
