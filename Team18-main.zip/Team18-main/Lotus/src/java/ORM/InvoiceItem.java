/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ORM;

/**
 *
 * @author Rajitha Yasasri
 */
public class InvoiceItem {

    private int idInvoiceItem;
    private int status_idstatus;
    private Cartitem cartitem;
    private Invoice invoice;

    /**
     * @return the idInvoiceItem
     */
    public int getIdInvoiceItem() {
        return idInvoiceItem;
    }

    /**
     * @param idInvoiceItem the idInvoiceItem to set
     */
    public void setIdInvoiceItem(int idInvoiceItem) {
        this.idInvoiceItem = idInvoiceItem;
    }

    /**
     * @return the status_idstatus
     */
    public int getStatus_idstatus() {
        return status_idstatus;
    }

    /**
     * @param status_idstatus the status_idstatus to set
     */
    public void setStatus_idstatus(int status_idstatus) {
        this.status_idstatus = status_idstatus;
    }

    /**
     * @return the cartitem
     */
    public Cartitem getCartitem() {
        return cartitem;
    }

    /**
     * @param cartitem the cartitem to set
     */
    public void setCartitem(Cartitem cartitem) {
        this.cartitem = cartitem;
    }

    /**
     * @return the i
     */
    public Invoice getInvoice() {
        return invoice;
    }

    /**
     * @param i the i to set
     */
    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }
}
