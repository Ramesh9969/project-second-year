/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ORM;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author Rajitha Yasasri
 */
public class Wishlistitem implements Serializable{

    private int idWishListItem;
    private Date date;
    private int status;
    private Selling selling;

    /**
     * @return the idWishListItem
     */
    public int getIdWishListItem() {
        return idWishListItem;
    }

    /**
     * @param idWishListItem the idWishListItem to set
     */
    public void setIdWishListItem(int idWishListItem) {
        this.idWishListItem = idWishListItem;
    }

    /**
     * @return the date
     */
    public Date getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the selling
     */
    public Selling getSelling() {
        return selling;
    }

    /**
     * @param selling the selling to set
     */
    public void setSelling(Selling selling) {
        this.selling = selling;
    }
}
