/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ORM;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author Rajitha Yasasri
 */
public class Selling implements Serializable{
    
    private int idSelling;
    private double qty;
    private double unitPrice;
    private double deliveryCharge;
    private String description;
    private Date date;
    private int idstatus;
    private int idProduct;
    private String name;
    private String type;
    private String unit;
    private String category;
    private String[] pics=new String[3];

    /**
     * @return the idSelling
     */
    public int getIdSelling() {
        return idSelling;
    }

    /**
     * @param idSelling the idSelling to set
     */
    public void setIdSelling(int idSelling) {
        this.idSelling = idSelling;
    }

    /**
     * @return the qty
     */
    public double getQty() {
        return qty;
    }

    /**
     * @param qty the qty to set
     */
    public void setQty(double qty) {
        this.qty = qty;
    }

    /**
     * @return the unitPrice
     */
    public double getUnitPrice() {
        return unitPrice;
    }

    /**
     * @param unitPrice the unitPrice to set
     */
    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    /**
     * @return the deliveryCharge
     */
    public double getDeliveryCharge() {
        return deliveryCharge;
    }

    /**
     * @param deliveryCharge the deliveryCharge to set
     */
    public void setDeliveryCharge(double deliveryCharge) {
        this.deliveryCharge = deliveryCharge;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the date
     */
    public Date getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * @return the idstatus
     */
    public int getIdstatus() {
        return idstatus;
    }

    /**
     * @param idstatus the idstatus to set
     */
    public void setIdstatus(int idstatus) {
        this.idstatus = idstatus;
    }

    /**
     * @return the idProduct
     */
    public int getIdProduct() {
        return idProduct;
    }

    /**
     * @param idProduct the idProduct to set
     */
    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the unit
     */
    public String getUnit() {
        return unit;
    }

    /**
     * @param unit the unit to set
     */
    public void setUnit(String unit) {
        this.unit = unit;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * @return the pics
     */
    public String[] getPics() {
        return pics;
    }

    /**
     * @param pics the pics to set
     */
    public void setPics(String[] pics) {
        this.pics = pics;
    }
    
    
}
