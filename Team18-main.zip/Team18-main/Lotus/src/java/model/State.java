/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Rajitha Yasasri
 */
public class State {

    public static final int REMOVED = 0;
    public static final int ACTIVE = 1;
    public static final int PENDING = 2;
    public static final int VIEWED = 3;
    public static final int REPLIED = 4;
    public static final int SHIPPED = 5;
    public static final int RECEIVED = 6;
    public static final int BUYITNOW = 7;

    /**
     * @return the REMOVED
     */
    public static int getREMOVED() {
        return REMOVED;
    }

    /**
     * @return the ACTIVE
     */
    public static int getACTIVE() {
        return ACTIVE;
    }

    /**
     * @return the PENDING
     */
    public static int getPENDING() {
        return PENDING;
    }

    /**
     * @return the VIEWED
     */
    public static int getVIEWED() {
        return VIEWED;
    }

    /**
     * @return the REPLIED
     */
    public static int getREPLIED() {
        return REPLIED;
    }

    /**
     * @return the SHIPPED
     */
    public static int getSHIPPED() {
        return SHIPPED;
    }

    /**
     * @return the RECEIVED
     */
    public static int getRECEIVED() {
        return RECEIVED;
    }

    /**
     * @return the BUYITNOW
     */
    public static int getBUYITNOW() {
        return BUYITNOW;
    }
}
