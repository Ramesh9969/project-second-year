/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Rajitha Yasasri
 */
public class Payment {

    private boolean sandbox = true;
    private int merchant_id = 1214253;
    private String return_url = "http://sample.com/return";
    private String cancel_url = "http://sample.com/cancel";
    private String notify_url = "http://sample.com/notify";
    private int order_id = 123;
    private String items = "Door bell wireles";
    private double amount = 1000.00;
    private String currency = "LKR";
    private String first_name = "Saman";
    private String last_name = "Perera";
    private String email = "samanp@gmail.com";
    private String phone = "0771234567";
    private String address = "No.1, Galle Road";
    private String city = "Colombo";
    private String country = "Sri Lanka";
    private String delivery_address = "No. 46, Galle road, Kalutara South";
    private String delivery_city = "Kalutara";
    private String delivery_country = "Sri Lanka";
    private String custom_1 = "";
    private String custom_2 = "";

    /**
     * @return the sandbox
     */
    public boolean isSandbox() {
        return sandbox;
    }

    /**
     * @param sandbox the sandbox to set
     */
    public void setSandbox(boolean sandbox) {
        this.sandbox = sandbox;
    }

    /**
     * @return the merchant_id
     */
    public int getMerchant_id() {
        return merchant_id;
    }

    /**
     * @param merchant_id the merchant_id to set
     */
    public void setMerchant_id(int merchant_id) {
        this.merchant_id = merchant_id;
    }

    /**
     * @return the return_url
     */
    public String getReturn_url() {
        return return_url;
    }

    /**
     * @param return_url the return_url to set
     */
    public void setReturn_url(String return_url) {
        this.return_url = return_url;
    }

    /**
     * @return the cancel_url
     */
    public String getCancel_url() {
        return cancel_url;
    }

    /**
     * @param cancel_url the cancel_url to set
     */
    public void setCancel_url(String cancel_url) {
        this.cancel_url = cancel_url;
    }

    /**
     * @return the notify_url
     */
    public String getNotify_url() {
        return notify_url;
    }

    /**
     * @param notify_url the notify_url to set
     */
    public void setNotify_url(String notify_url) {
        this.notify_url = notify_url;
    }

    /**
     * @return the order_id
     */
    public int getOrder_id() {
        return order_id;
    }

    /**
     * @param order_id the order_id to set
     */
    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    /**
     * @return the items
     */
    public String getItems() {
        return items;
    }

    /**
     * @param items the items to set
     */
    public void setItems(String items) {
        this.items = items;
    }

    /**
     * @return the amount
     */
    public double getAmount() {
        return amount;
    }

    /**
     * @param amount the amount to set
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * @return the currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * @param currency the currency to set
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * @return the first_name
     */
    public String getFirst_name() {
        return first_name;
    }

    /**
     * @param first_name the first_name to set
     */
    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    /**
     * @return the last_name
     */
    public String getLast_name() {
        return last_name;
    }

    /**
     * @param last_name the last_name to set
     */
    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @return the delivery_address
     */
    public String getDelivery_address() {
        return delivery_address;
    }

    /**
     * @param delivery_address the delivery_address to set
     */
    public void setDelivery_address(String delivery_address) {
        this.delivery_address = delivery_address;
    }

    /**
     * @return the delivery_city
     */
    public String getDelivery_city() {
        return delivery_city;
    }

    /**
     * @param delivery_city the delivery_city to set
     */
    public void setDelivery_city(String delivery_city) {
        this.delivery_city = delivery_city;
    }

    /**
     * @return the delivery_country
     */
    public String getDelivery_country() {
        return delivery_country;
    }

    /**
     * @param delivery_country the delivery_country to set
     */
    public void setDelivery_country(String delivery_country) {
        this.delivery_country = delivery_country;
    }

    /**
     * @return the custom_1
     */
    public String getCustom_1() {
        return custom_1;
    }

    /**
     * @param custom_1 the custom_1 to set
     */
    public void setCustom_1(String custom_1) {
        this.custom_1 = custom_1;
    }

    /**
     * @return the custom_2
     */
    public String getCustom_2() {
        return custom_2;
    }

    /**
     * @param custom_2 the custom_2 to set
     */
    public void setCustom_2(String custom_2) {
        this.custom_2 = custom_2;
    }
}
