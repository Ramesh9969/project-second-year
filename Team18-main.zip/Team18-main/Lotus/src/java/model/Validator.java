/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Rajitha Yasasri
 */
public class Validator {

    public static boolean isValidEmail(String text) {

        if (isEmptyText(text)) {
            return false;
        }

        Pattern p = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

        Matcher m = p.matcher(text);

        if (m.matches()) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean isValidNumber(String text) {
//can validate decimal numbers(10.56..etc) too
        if (isEmptyText(text)) {
            return false;
        }

        String exp = "-?(\\d+|\\d+\\.\\d+|\\.\\d+)([eE][-+]?\\d+)?";
        Pattern p = Pattern.compile(exp);

        Matcher m = p.matcher(text);

        if (m.matches()) {
            return true;
        } else {
            return false;
        }

    }

    public static boolean isValidPhoneNumber(String text) {

        if (isEmptyText(text)) {

            return false;
        }

        if (text.length() == 10) {

            String firstDigit = text.substring(0, 1);
            if (!firstDigit.equals("0")) {
                return false;
            }

            if (isValidNumber(text)) {
                return true;
            } else {

                return false;
            }
        } else {
            return false;
        }
    }

    public static boolean isValidString(String text) {

        if (isEmptyText(text)) {
            return false;
        }

        String exp = "[A-Za-z]*";
        Pattern p = Pattern.compile(exp);

        Matcher m = p.matcher(text);

        if (m.matches()) {
            return true;
        } else {
            return false;
        }

    }

    public static boolean isValidAddressString(String text) {

        if (isEmptyText(text)) {
            return false;
        }

        String exp = "[\\,a-zA-Z\\\\/\\,\\s\\w\\.]*";
        Pattern p = Pattern.compile(exp);

        Matcher m = p.matcher(text);

        if (m.matches()) {
            return true;
        } else {
            return false;
        }

    }

    public static boolean isEmptyText(String text) {

        if (text == null) {
            return true;
        }
        if (text.isEmpty()) {
            return true;
        }
        return false;
    }

    public static boolean isNotEmptyText(String text) {

        return !isEmptyText(text);
    }

    public static boolean isNotEmptyTextMany(String... text) {

        for (String string : text) {

            boolean emptyString = isEmptyText(string);
            if (emptyString) {

                return false;
            }
        }

        return true;
    }

    public static boolean isValidStringMany(String... text) {

        for (String string : text) {
            boolean validString = isValidString(string);
            if (validString) {
                //nothing to do
            } else {
                System.out.println("not valid: " + string);
                return false;
            }
        }
        return true;
    }
}
