/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Rajitha Yasasri
 */
public class DefaultItems {

    private static final String DEFAULT_PRODUCT_IMAGE_PATH = "default-product.jpg";
    private static final int DEFAULT_PROFILE_IMAGE_ID = 2;//"default.png";
    private static final String DEFAULT_PROFILE_IMAGE_PATH = "default.png";
    private static final int DEFAULT_GENDER_TYPE = 1;

    public static String getDefaultProductImagePath() {
        return DEFAULT_PRODUCT_IMAGE_PATH;
    }

    public static int getDefaultGenderType() {
        return DEFAULT_GENDER_TYPE;
    }

    public static int getDefaultProfileImageID() {
        return DEFAULT_PROFILE_IMAGE_ID;
    }

    public static String getDefaultProfileImagePath() {
        return DEFAULT_PROFILE_IMAGE_PATH;
    }
}
